const fs = require('fs');
function findAll(path, {typeName, fileName}) {

    let list

    if (typeName){
        let list = fs
            .readdirSync(path)
            .filter(fileName => fileName.endsWith(typeName))
            .map(fileName => fileName.replace(".js",''));
        // let listFiltered = list.filter(fileName => fileName.endsWith(typeName)); //필터로 걸러서 껴줄지 말지 정함
        // let listF = list.filter(fileName=>fileName.length>5)
        // let listMapped = list.map(fileName => `<${fileName}>`); // 맘대로 변환하기
        // let listMapped = list.map(fileName => fileName.replace(".js",''));
        return list
    }

    return list;
}

//exports 의 속성으로 추가 하는 것
exports.findAll = findAll;