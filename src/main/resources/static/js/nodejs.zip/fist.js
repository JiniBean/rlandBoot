let repository = require('./file-repository');
// console.log("안녕 나는");

// console.log(repository.findAll("./",{}));
console.log(repository.findAll("./", {
    typeName:".js"
}));

